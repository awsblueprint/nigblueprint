<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'bmwiZu/mS5;g:M,y,^&-O#P`|=^3gUJ9zHNsY@9}$6HfX0`f>n{e{vcPwgadNKhQ' );
define( 'SECURE_AUTH_KEY',   'd3M,si-DM0Vo90zgCZH,9<=[v(J GirG6Fj8_7o`RrWupBdM}=J2$j7WG}/.ujoT' );
define( 'LOGGED_IN_KEY',     'XEm[V)bKLo^rp$nS;bDV!&Hl2N+ui+A2%W-La- +b]m}zMUhP4nbK/KkQ/M:PB.Y' );
define( 'NONCE_KEY',         '[4UEfbC<LeJQjoKe.3].0S|D>LG[NNsdpa:yK>#3]/,?TUvRQX>UZR=+-aC[`//K' );
define( 'AUTH_SALT',         '%+Uspw#JO2*3t#rJ7/iuqJ9%(#zlRJVi9wCiD[8VM@G,zIQ!;jO1P;/f_Zg^_2kp' );
define( 'SECURE_AUTH_SALT',  'O^6g>ZN#6%9q.vXM8zpUX}5J,.To%ODNh7xbC2|! {3Y~O^O&~6(uA=A:yhEu*:7' );
define( 'LOGGED_IN_SALT',    ';^2qWo~rX9J[TN{u5klXkP;2T/eGJJeEPq%HB^hdAQv^e,^B?*I!r~7is%PU)D!2' );
define( 'NONCE_SALT',        '>8^&~]=vEwR_hwtzjJA.XjW9_xjn6Rrn!%O|Gi@YHlMQ{zqGV58=`/9;%t]rx_l<' );
define( 'WP_CACHE_KEY_SALT', 'vw(=K92&O>TLFaJc~Sc#6msz3u#ps7Q1ue=oWZEd9 6#ei}lD7[3wtI1-hgT(JxH' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
